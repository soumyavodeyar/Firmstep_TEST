from icalendar import Calendar, Event
from datetime import datetime
from icalendar import Calendar
import urllib
ics = urllib.urlopen('https://s3-eu-west-1.amazonaws.com/fs-downloads/GM/binfeed.ical').read()
ical=Calendar.from_ical(ics)

dictionary={}   ### creating a dictionary with UID as a key
for vevent in ical.subcomponents:
    if vevent.name != "VEVENT":
        continue
    UID = str(vevent.get('UID'))
    DTSTAMP = str(vevent.get('DTSTAMP'))
    DTSTART = vevent.get('DTSTART').dt     # a datetime
    summary = str(vevent.get('SUMMARY'))
    value_tuple = (UID,DTSTAMP,summary)  
    if DTSTART in dictionary:
          dictionary[DTSTART].append(value_tuple)
    else:
        dictionary[DTSTART] = []
        dictionary[DTSTART].append(value_tuple)

sd = sorted(dictionary.keys()) 
print "the sorted dates are:", sd

def start():
    while True:
        input_dates= raw_input("Type Date in the formate %YYYY, %mm, %dd:  ")
        try:
            dates = datetime.strptime(input_dates, '%Y, %m, %d')
            mydate = datetime.date(dates)
            search_bin_data(mydate)
            break
        except:
            print "Incorrect data format, should be YYYY, MM, DD"
            continue
            return input_dates

def search_bin_data(mydate):
    if mydate not in dictionary.keys():
        print  "date not in bin collection data"
        conti()
    else:
        print "The UID is:" ,[x[0] for x in dictionary[mydate]]
        print "The DTSTART is: " , [y[1] for y in dictionary[mydate]]
        print "The summary is:",[z[2] for z in dictionary[mydate]]       
        conti()

def conti():    
    confirmation = raw_input("DO YOU WANT TO CONTINUE WITH THE OTHER OPTIONS......Press Y for Yes and N for No")
    if confirmation == 'Y':
       start()
    elif confirmation == 'N':
        print "THANK YOU!!!!!!!!:)"
    else:
        print "ENTER 'Y' OR 'N' "
        conti()
start()

import unittest
import datetime
class search_test(unittest.TestCase):
    
    def testMatches(self):
        search_bin_data(datetime.date(2014, 12, 2))

def main():
    unittest.main()

if __name__ == '__main__':
    main()
